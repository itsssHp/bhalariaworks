// ✅ Enable client-side rendering in Next.js
"use client";

import { useRouter } from "next/navigation"; // ⛳ For navigation after logout
import { auth } from "@/lib/firebase"; // 🔐 Firebase Auth instance
import { signOut } from "firebase/auth"; // 🚪 Sign out function
import { useEffect, useState } from "react";
import { getDocs, collection, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase"; // 🗄️ Firestore database instance

// 📌 Top navigation bar for Admin Panel
export default function Navbar() {
  const router = useRouter();

  // 🧠 Local state for user display name and role
  const [userName, setUserName] = useState("");
  const [userRole, setUserRole] = useState("");

  // 🔄 Fetch the logged-in user's info from Firestore
  useEffect(() => {
    const fetchUserInfo = async () => {
      const user = auth.currentUser;
      if (!user) return; // 🚫 No logged-in user

      // 🔍 Query the "employees" collection for the user's UID
      const q = query(
        collection(db, "employees"),
        where("uid", "==", user.uid)
      );
      const snapshot = await getDocs(q);

      if (!snapshot.empty) {
        const data = snapshot.docs[0].data();
        setUserName(data.name || ""); // 🧾 Fallback to empty string if undefined
        setUserRole(data.role || "");
      }
    };

    fetchUserInfo(); // 🚀 Call on mount
  }, []);

  // 🔐 Logout the current user and redirect to login page
  const handleLogout = async () => {
    await signOut(auth);
    router.push("/login");
  };

  // 🧱 Navbar UI layout
  return (
    <header className="bg-white dark:bg-gray-800 shadow sticky top-0 z-30 px-4 py-2 flex justify-between items-center">
      {/* 🌐 App Name */}
      <div className="text-xl font-semibold text-blue-600">Bhalaria Admin</div>

      {/* 👤 User Info Section */}
      <div className="flex items-center gap-4 text-sm text-gray-700 dark:text-white">
        {/* 🧑 Display Name */}
        <span>{userName}</span>

        {/* 🏷️ Role Badge */}
        <span className="px-2 py-1 rounded bg-blue-100 text-blue-700 text-xs font-semibold capitalize">
          {userRole}
        </span>

        {/* 🚪 Logout Button */}
        <button
          onClick={handleLogout}
          className="bg-white text-blue-600 px-3 py-1 rounded font-medium hover:bg-gray-100 transition"
        >
          Logout
        </button>
      </div>
    </header>
  );
}
