"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  FaUsers,
  FaTachometerAlt,
  FaClipboardList,
  FaUserShield,
  FaCalendarCheck,
  FaUserPlus,
  FaBars,
  FaTimes,
  FaSignOutAlt,
  FaFolderOpen,
} from "react-icons/fa";
import { db } from "@/lib/firebase";
import { collection, getDocs, query, where } from "firebase/firestore";
import { cn } from "@/lib/utils";

interface SidebarLink {
  href: string;
  label: string;
  icon: React.ReactNode;
  showBadge?: boolean;
  section?: string;
}

export default function AdminSidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [pendingCount, setPendingCount] = useState<number>(0);
  const [search, setSearch] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("admin-sidebar-collapsed");
    setCollapsed(saved === "true");
  }, []);

  useEffect(() => {
    localStorage.setItem("admin-sidebar-collapsed", String(collapsed));
  }, [collapsed]);

  useEffect(() => {
    async function fetchPendingLeaves() {
      const q = query(
        collection(db, "leave-requests"),
        where("status", "==", "Pending")
      );
      const snap = await getDocs(q);
      setPendingCount(snap.size);
    }
    fetchPendingLeaves();
  }, []);

  const links: SidebarLink[] = [
    {
      href: "/admin/dashboard",
      label: "Dashboard",
      icon: <FaTachometerAlt />,
      section: "Overview",
    },
    {
      href: "/admin/employees",
      label: "Employee Directory",
      icon: <FaUsers />,
      section: "Management",
    },
    {
      href: "/admin/attendance",
      label: "Attendance",
      icon: <FaCalendarCheck />,
      section: "Management",
    },
    {
      href: "/admin/leaves",
      label: "Leave Requests",
      icon: <FaClipboardList />,
      section: "Management",
      showBadge: pendingCount > 0,
    },
    {
      href: "/admin/roles",
      label: "Role Management",
      icon: <FaUserShield />,
      section: "Management",
    },
    {
      href: "/admin/projects",
      label: "Projects",
      icon: <FaFolderOpen />,
      section: "Projects",
    },
    {
      href: "/admin/create-user",
      label: "Create User",
      icon: <FaUserPlus />,
      section: "Settings",
    },
    {
      href: "/admin/profile",
      label: "Profile",
      icon: <FaUserShield />,
      section: "Settings",
    },
  ];

  const isActive = (href: string) => pathname?.startsWith(href) ?? false;

  const handleLogout = () => {
    localStorage.removeItem("isAdminLoggedIn");
    window.location.href = "/login";
  };

  // Group links by section
  const groupedLinks = links.reduce((acc, link) => {
    const section = link.section || "Other";
    if (!acc[section]) acc[section] = [];
    acc[section].push(link);
    return acc;
  }, {} as Record<string, SidebarLink[]>);

  return (
    <aside
      className={cn(
        "bg-white dark:bg-gray-900 text-gray-800 dark:text-white shadow-lg h-screen fixed top-0 left-0 z-40 transition-all duration-300",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Top bar */}
      <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
        <span
          className={cn(
            "text-xl font-bold text-blue-600",
            collapsed && "hidden"
          )}
        >
          Bhalaria Works
        </span>
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="text-gray-600 dark:text-gray-300 focus:outline-none"
        >
          {collapsed ? <FaBars /> : <FaTimes />}
        </button>
      </div>

      {/* Search */}
      {!collapsed && (
        <div className="p-3">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search..."
            className="w-full px-3 py-2 rounded-md border dark:bg-gray-800 dark:border-gray-600"
          />
        </div>
      )}

      {/* Navigation */}
      <nav className="mt-2 space-y-2">
        {Object.entries(groupedLinks).map(([section, items]) => (
          <div key={section}>
            {!collapsed && (
              <div className="text-xs font-bold uppercase text-gray-400 px-4 mt-4 mb-1">
                {section}
              </div>
            )}
            {items
              .filter((link) =>
                link.label.toLowerCase().includes(search.toLowerCase())
              )
              .map((link) => (
                <Link key={link.href} href={link.href}>
                  <div
                    className={cn(
                      "flex items-center gap-3 px-4 py-2 mx-2 rounded-md cursor-pointer hover:bg-blue-50 dark:hover:bg-gray-800 transition-all",
                      isActive(link.href)
                        ? "bg-blue-100 dark:bg-gray-800 text-blue-700 dark:text-white font-semibold"
                        : "text-gray-700 dark:text-gray-300"
                    )}
                  >
                    <span className="text-lg transition-transform duration-200">
                      {link.icon}
                    </span>
                    {!collapsed && (
                      <span className="flex-1">
                        {link.label}
                        {link.showBadge && (
                          <span className="ml-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
                            {pendingCount}
                          </span>
                        )}
                      </span>
                    )}
                  </div>
                </Link>
              ))}
          </div>
        ))}

        {/* Logout */}
        <button
          onClick={handleLogout}
          className={cn(
            "flex items-center gap-3 px-4 py-2 mx-2 rounded-md text-red-600 hover:bg-red-100 transition",
            collapsed && "justify-center"
          )}
        >
          <FaSignOutAlt />
          {!collapsed && <span>Logout</span>}
        </button>
      </nav>
    </aside>
  );
}
