"use client";

import { useState } from "react";
import { updateDoc, doc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import toast from "react-hot-toast";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
interface Employee {
  id: string;
  fullName: string;
  email: string;
  employeeId: string;
  department: string;
  role: string;
  status: string;
  position?: string;
  phone?: string;
  address?: string;
  joinDate?: string;
  birthDate?: string;
  photoURL?: string;
}

interface EditEmployeeModalProps {
  employee: Employee;
  onClose: () => void;
  refresh?: () => Promise<void>; // ✅ add this
}

export default function EditEmployeeModal({
  employee,
  onClose,
  refresh,
}: EditEmployeeModalProps) {
  const [form, setForm] = useState<Employee>({ ...employee });

  // Convert string to Date for DatePickers
  const parseDate = (dateStr?: string) =>
    dateStr ? new Date(dateStr) : undefined;

  const handleChange = (field: keyof Employee, value: string | undefined) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    const { fullName, email, department, status, position, joinDate } = form;

    if (
      !fullName ||
      !email ||
      !department ||
      !status ||
      !position ||
      !joinDate
    ) {
      toast.error("Please fill all required fields.");
      return;
    }

    try {
      await updateDoc(doc(db, "employees", employee.id), {
        ...form,
      });
      toast.success("Employee updated.");
      onClose();
      if (refresh) await refresh();
    } catch (error) {
      console.error(error);
      toast.error("Update failed.");
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-center justify-center px-4">
      <div className="bg-white dark:bg-gray-900 p-6 rounded-lg w-full max-w-2xl shadow-lg overflow-y-auto max-h-[90vh] space-y-4 animate-fadeIn">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white">
          Edit Employee
        </h2>

        {/* Grid Form */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium">Full Name *</label>
            <input
              type="text"
              value={form.fullName}
              onChange={(e) => handleChange("fullName", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            />
          </div>
          <div>
            <label className="block text-sm font-medium">Position *</label>
            <input
              type="text"
              value={form.position}
              onChange={(e) => handleChange("position", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Department *</label>
            <select
              value={form.department}
              onChange={(e) => handleChange("department", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            >
              <option value="">Select</option>
              <option value="Production">Production</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Admin">Admin</option>
              <option value="HR">HR</option>
              <option value="Dispatch">Dispatch</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium">Email *</label>
            <input
              type="email"
              value={form.email}
              onChange={(e) => handleChange("email", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Phone</label>
            <input
              type="text"
              value={form.phone || ""}
              onChange={(e) => handleChange("phone", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Join Date *</label>
            <DatePicker
              selected={parseDate(form.joinDate)}
              onChange={(date) =>
                handleChange("joinDate", date?.toISOString().split("T")[0])
              }
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
              dateFormat="MMMM d, yyyy"
            />
          </div>

          <div>
            <label className="block text-sm font-medium">Status *</label>
            <select
              value={form.status}
              onChange={(e) => handleChange("status", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
            >
              <option value="">Select</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium">Birth Date</label>
            <DatePicker
              selected={parseDate(form.birthDate)}
              onChange={(date) =>
                handleChange("birthDate", date?.toISOString().split("T")[0])
              }
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
              dateFormat="MMMM d, yyyy"
              showYearDropdown
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-sm font-medium">Address</label>
            <textarea
              value={form.address || ""}
              onChange={(e) => handleChange("address", e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm dark:bg-gray-800 dark:text-white"
              rows={2}
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="flex justify-end gap-2 pt-2">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm bg-gray-200 dark:bg-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="px-4 py-2 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded-md"
          >
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
}
