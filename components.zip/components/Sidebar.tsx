"use client";

import Link from "next/link";
import { useState } from "react";
import {
  HiOutlineHome,
  HiOutlineClipboardList,
  HiOutlineBriefcase,
  HiOutlineDocumentText,
  HiOutlineUserGroup,
  HiOutlineLogout,
  HiMenuAlt3,
  HiOutlineUsers,
} from "react-icons/hi";
import { useRouter } from "next/navigation";
import { signOut } from "firebase/auth";
import { auth } from "@/lib/firebase";

const links = [
  { name: "Dashboard", href: "/hr/dashboard", icon: <HiOutlineHome /> },
  { name: "Payroll", href: "/hr/payroll", icon: <HiOutlineClipboardList /> },
  { name: "Post Jobs", href: "/hr/jobs", icon: <HiOutlineBriefcase /> },
  { name: "Policies", href: "/hr/policies", icon: <HiOutlineDocumentText /> },
  {
    name: "Job Applications",
    href: "/hr/jobapplications",
    icon: <HiOutlineUserGroup />,
  },
  { name: "Employees", href: "/hr/employees", icon: <HiOutlineUsers /> }, // ✅ New
];

export default function Sidebar() {
  const [open, setOpen] = useState(true);
  const router = useRouter();

  const handleLogout = async () => {
    await signOut(auth);
    router.push("/login");
  };

  return (
    <div
      className={`flex flex-col bg-blue-800 text-white transition-all duration-300 ${
        open ? "w-64" : "w-20"
      } min-h-screen`}
    >
      <div className="flex items-center justify-between px-4 py-4 border-b border-blue-700">
        <button onClick={() => setOpen(!open)} className="text-white text-2xl">
          <HiMenuAlt3 />
        </button>
        {open && <h1 className="text-xl font-bold tracking-wide">Bhalaria</h1>}
      </div>

      <nav className="flex-1 px-2 py-4 space-y-2">
        {links.map((link) => (
          <Link
            key={link.name}
            href={link.href}
            className="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-blue-700 transition-all"
          >
            <span className="text-xl">{link.icon}</span>
            {open && <span className="text-sm font-medium">{link.name}</span>}
          </Link>
        ))}
      </nav>

      <div className="px-4 py-4 border-t border-blue-700">
        <button
          onClick={handleLogout}
          className="flex items-center space-x-3 text-sm hover:text-red-300"
        >
          <HiOutlineLogout className="text-lg" />
          {open && <span>Logout</span>}
        </button>
      </div>
    </div>
  );
}
