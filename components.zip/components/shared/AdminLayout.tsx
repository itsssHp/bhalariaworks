// components/shared/AdminLayout.tsx
"use client";

import { ThemeProvider } from "next-themes";
import AdminSidebar from "@/components/admin/AdminSidebar";
import HeaderBar from "@/components/shared/HeaderBar";

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <div className="flex min-h-screen bg-background text-foreground transition-colors duration-300">
        <AdminSidebar />
        <div className="flex flex-col flex-1">
          <HeaderBar />
          <main className="p-4">{children}</main>
        </div>
      </div>
    </ThemeProvider>
  );
}
