"use client"; // 🔧 Required for client-side hooks and router

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { auth, db } from "@/lib/firebase";
import { onAuthStateChanged } from "firebase/auth";
import { getDocs, collection, query, where } from "firebase/firestore";

// 🎯 Props for RoleGuard component
interface RoleGuardProps {
  allowedRoles: string[]; // List of allowed roles e.g. ['admin', 'super-admin']
  children: React.ReactNode; // Components to render if authorized
}

// 🔐 RoleGuard: Protects routes based on user's role
export default function RoleGuard({ allowedRoles, children }: RoleGuardProps) {
  const router = useRouter(); // Used for redirects
  const [checking, setChecking] = useState(true); // Loading state while verifying user

  useEffect(() => {
    // 📡 Firebase auth listener to detect login state
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        console.warn("❌ No user logged in. Redirecting to login...");
        router.push("/login"); // Redirect to login if no user
        return;
      }

      try {
        // 🔍 Query the Firestore 'employees' collection by UID
        const q = query(
          collection(db, "employees"),
          where("uid", "==", user.uid)
        );
        const snapshot = await getDocs(q);

        if (snapshot.empty) {
          console.warn("❌ UID not found in employees collection");
          router.push("/unauthorized");
          return;
        }

        // ✅ Extract and normalize the role
        const rawRole = snapshot.docs[0].data().role;
        const role = rawRole?.toString().trim().toLowerCase() ?? "unknown";

        // 🧪 Debug logs
        console.log("🔐 Authenticated UID:", user.uid);
        console.log("🎭 Role from Firestore:", role);
        console.log("✅ Allowed roles:", allowedRoles);

        // 🚫 If role is not allowed, redirect
        if (!allowedRoles.map((r) => r.toLowerCase()).includes(role)) {
          console.warn("❌ Access denied for role:", role);
          router.push("/unauthorized");
          return;
        }

        // ✅ Role is valid → allow access
        setChecking(false);
      } catch (error) {
        console.error("🔥 Error validating role:", error);
        router.push("/unauthorized");
      }
    });

    // 🧼 Cleanup listener on unmount
    return () => unsubscribe();
  }, [allowedRoles, router]);

  // ⏳ Show loading indicator while verifying
  if (checking) {
    return (
      <p className="text-center mt-10 text-gray-500 dark:text-gray-300">
        🔐 Verifying access...
      </p>
    );
  }

  // ✅ Authorized user → render protected content
  return <>{children}</>;
}
